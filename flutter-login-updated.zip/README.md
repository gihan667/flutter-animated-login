## Flutter Animated Login by Code Crafts

Beautifully crafted login & sign up screens for your next project.

### Follow us

- [Subscribe us](https://www.youtube.com/c/CodeCrafts)
- [Instagram](https://www.instagram.com/codecrafts)
- [Facebook](https://www.facebook.com/codecraftsl)

Do you have project in your mind? Just connect with us

- Email: info@codecrafts.dev
- Whats App: +94 7755 80 646

### Preview

![App UI](/preview.gif)